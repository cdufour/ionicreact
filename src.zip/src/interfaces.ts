export interface Player{
    firstname: string;
    lastname: string;
    team: string;
    //team: Team;
    position: string;
}

export interface Team{
    name: string;
}